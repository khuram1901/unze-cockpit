"use client";

import { useEffect, useRef, useState } from "react";
import AuthWrapper from "../lib/AuthWrapper";
import { useRequireCapability } from "../lib/useRouteGuard";
import { supabase } from "../lib/supabase";
import { formatDateTimeUK, formatDateUK } from "../lib/dateUtils";
import { useMobile } from "../lib/useMobile";
import { COLOURS, PageHeader, SectionTitle, CountCard, SkeletonRows } from "../lib/SharedUI";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";

type LogEntry = {
  id: string;
  user_email: string;
  user_name: string | null;
  action: string;
  table_name: string;
  record_id: string | null;
  details: string | null;
  created_at: string;
};

const TABLE_LABELS: Record<string, string> = {
  tasks: "Tasks",
  members: "Members",
  audit_plan_items: "Audit",
  legal_notices: "Taxation",
  recruitment_positions: "HR",
  meeting_requests: "Meetings",
  meetings: "Meetings",
  meeting_tasks: "Meetings",
  cash_opening_balance: "Finance",
  monthly_cash_plan: "Finance",
  daily_cash_position: "Finance",
  monthly_budgets: "Finance",
  production_entries: "Production",
  dispatch_entries: "Dispatch",
  breakage_entries: "Breakage",
  machine_issues: "Machines",
  department_owners: "Dept Owners",
  opening_balances: "Opening Bal.",
  receivables: "Receivables",
};

function getDept(tableName: string): string {
  return TABLE_LABELS[tableName] || tableName;
}

const ACTION_COLOURS: Record<string, { bg: string; text: string }> = {
  Created: { bg: "#dcfce7", text: COLOURS.GREEN },
  Updated: { bg: "#fef3c7", text: COLOURS.AMBER },
  Deleted: { bg: "#fee2e2", text: COLOURS.RED },
};

type AuditStats = {
  total_count: number;
  today_count: number;
  created_count: number;
  updated_count: number;
  deleted_count: number;
};

const EMPTY_STATS: AuditStats = { total_count: 0, today_count: 0, created_count: 0, updated_count: 0, deleted_count: 0 };

export default function AuditLogPage() {
  const { checking } = useRequireCapability("audit_log");
  const isMobile = useMobile();
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");
  const [groupBy, setGroupBy] = useState<"time" | "department" | "person">("time");
  // KPI counts and the department donut are computed in the database (get_audit_log_stats /
  // get_audit_log_department_breakdown) over the FULL table — the live table already has
  // 1,000+ rows, more than the 500-row display fetch below, so these can never be derived
  // correctly by counting only the rows shown on screen.
  const [stats, setStats] = useState<AuditStats>(EMPTY_STATS);
  const [deptBreakdown, setDeptBreakdown] = useState<{ department: string; entry_count: number }[]>([]);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { loadLogs(); loadStats(""); }, []);

  async function loadLogs() {
    setLoading(true);
    const { data } = await supabase
      .from("audit_log")
      .select("id, user_email, user_name, action, table_name, record_id, details, created_at")
      .order("created_at", { ascending: false })
      .limit(500);
    setLogs(data || []);
    setLoading(false);
  }

  async function loadStats(search: string) {
    const [statsRes, deptRes] = await Promise.all([
      supabase.rpc("get_audit_log_stats", { p_search: search || null }),
      supabase.rpc("get_audit_log_department_breakdown", { p_search: search || null }),
    ]);
    setStats(statsRes.data?.[0] || EMPTY_STATS);
    setDeptBreakdown(deptRes.data || []);
  }

  function handleFilterChange(v: string) {
    setFilter(v);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => loadStats(v), 300);
  }

  const filtered = filter
    ? logs.filter((l) =>
        l.user_name?.toLowerCase().includes(filter.toLowerCase()) ||
        l.user_email.toLowerCase().includes(filter.toLowerCase()) ||
        l.table_name.toLowerCase().includes(filter.toLowerCase()) ||
        l.action.toLowerCase().includes(filter.toLowerCase()) ||
        l.details?.toLowerCase().includes(filter.toLowerCase()) ||
        getDept(l.table_name).toLowerCase().includes(filter.toLowerCase())
      )
    : logs;

  // Action donut — driven by the DB-computed stats, not the capped 500-row fetch above.
  const actionDonut = [
    { name: "Created", value: stats.created_count, color: COLOURS.GREEN },
    { name: "Updated", value: stats.updated_count, color: COLOURS.AMBER },
    { name: "Deleted", value: stats.deleted_count, color: COLOURS.RED },
  ].filter((d) => d.value > 0);

  // Department donut — driven by get_audit_log_department_breakdown (full table), not the
  // capped 500-row fetch above.
  const deptColors: Record<string, string> = {
    Tasks: COLOURS.AMBER, Members: COLOURS.BLUE, Audit: COLOURS.PURPLE, Taxation: COLOURS.RED,
    HR: COLOURS.TEAL, Meetings: COLOURS.NAVY, Finance: COLOURS.GREEN, Production: COLOURS.GREEN,
    Dispatch: COLOURS.TEAL, Breakage: COLOURS.RED, Machines: COLOURS.RED,
  };
  const deptDonut = deptBreakdown.map((d) => ({
    name: d.department,
    value: d.entry_count,
    color: deptColors[d.department] || COLOURS.SLATE,
  }));

  // Group by department
  const deptGroups = new Map<string, LogEntry[]>();
  for (const l of filtered) {
    const d = getDept(l.table_name);
    if (!deptGroups.has(d)) deptGroups.set(d, []);
    deptGroups.get(d)!.push(l);
  }
  const deptNames = Array.from(deptGroups.keys()).sort((a, b) => (deptGroups.get(b)?.length || 0) - (deptGroups.get(a)?.length || 0));

  // Group by person
  const personGroups = new Map<string, LogEntry[]>();
  for (const l of filtered) {
    const p = l.user_name || l.user_email;
    if (!personGroups.has(p)) personGroups.set(p, []);
    personGroups.get(p)!.push(l);
  }
  const personNames = Array.from(personGroups.keys()).sort((a, b) => (personGroups.get(b)?.length || 0) - (personGroups.get(a)?.length || 0));

  function ActionBadge({ action }: { action: string }) {
    const key = action.startsWith("Updated") ? "Updated" : action;
    const c = ACTION_COLOURS[key] || { bg: "#f1f5f9", text: COLOURS.SLATE };
    return (
      <span style={{ fontSize: "11px", fontWeight: 700, padding: "1px 7px", borderRadius: "6px", backgroundColor: c.bg, color: c.text }}>{action}</span>
    );
  }

  function LogRow({ log }: { log: LogEntry }) {
    return (
      <div style={{ padding: "8px 14px", borderBottom: "1px solid var(--border-light, #f1f5f9)", display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "8px" }}>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: "16px", color: `var(--text-primary, ${COLOURS.NAVY})`, display: "flex", alignItems: "center", gap: "6px", flexWrap: "wrap" }}>
            <span style={{ fontWeight: 600 }}>{log.user_name || log.user_email}</span>
            <ActionBadge action={log.action} />
            <span style={{ fontSize: "14px", fontWeight: 600, color: COLOURS.BLUE }}>{getDept(log.table_name)}</span>
          </div>
          {log.details && <div style={{ fontSize: "14px", color: `var(--text-secondary, ${COLOURS.SLATE})`, marginTop: "2px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{log.details}</div>}
        </div>
        <div style={{ fontSize: "14px", color: `var(--text-secondary, ${COLOURS.SLATE})`, whiteSpace: "nowrap", flexShrink: 0 }}>
          {formatDateTimeUK(log.created_at)}
        </div>
      </div>
    );
  }

  if (checking) return <AuthWrapper><main style={{ padding: "14px 18px" }}><p style={{ color: `var(--text-secondary, ${COLOURS.SLATE})` }}>Checking permissions...</p></main></AuthWrapper>;

  return (
    <AuthWrapper>
        <main style={{ padding: isMobile ? "12px 14px" : "20px 24px", maxWidth: "100%", minWidth: 0 }}>
          <PageHeader />

          {/* KPI Row */}
          {!loading && (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(100px, 1fr))", gap: "8px", marginBottom: "14px" }}>
              <CountCard label="Today" value={stats.today_count} color={COLOURS.BLUE} />
              <CountCard label="Created" value={stats.created_count} color={COLOURS.GREEN} />
              <CountCard label="Updated" value={stats.updated_count} color={COLOURS.AMBER} />
              <CountCard label="Deleted" value={stats.deleted_count} color={COLOURS.RED} />
              <CountCard label="Total" value={stats.total_count} color={COLOURS.NAVY} />
            </div>
          )}

          {/* Charts row */}
          {!loading && stats.total_count > 0 && (
            <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: "14px", marginBottom: "14px" }}>
              {actionDonut.length > 0 && (
                <div style={{ border: `1px solid var(--border-color, ${COLOURS.HAIRLINE})`, borderRadius: "8px", padding: "14px", backgroundColor: "var(--bg-card, #ffffff)" }}>
                  <div style={{ fontSize: "16px", fontWeight: 700, color: `var(--text-primary, ${COLOURS.NAVY})`, marginBottom: "6px" }}>By Action</div>
                  <ResponsiveContainer width="100%" height={150}>
                    <PieChart>
                      <Pie data={actionDonut} cx="50%" cy="50%" innerRadius={35} outerRadius={60} dataKey="value" paddingAngle={2}>
                        {actionDonut.map((d, i) => <Cell key={i} fill={d.color} />)}
                      </Pie>
                      <Tooltip formatter={(value, name) => [`${value} entries`, name]} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div style={{ display: "flex", gap: "10px", justifyContent: "center", flexWrap: "wrap" }}>
                    {actionDonut.map((d) => (
                      <div key={d.name} style={{ display: "flex", alignItems: "center", gap: "3px", fontSize: "13px", color: `var(--text-secondary, ${COLOURS.SLATE})` }}>
                        <span style={{ width: "7px", height: "7px", borderRadius: "50%", backgroundColor: d.color }} /> {d.name} ({d.value})
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {deptDonut.length > 0 && (
                <div style={{ border: `1px solid var(--border-color, ${COLOURS.HAIRLINE})`, borderRadius: "8px", padding: "14px", backgroundColor: "var(--bg-card, #ffffff)" }}>
                  <div style={{ fontSize: "16px", fontWeight: 700, color: `var(--text-primary, ${COLOURS.NAVY})`, marginBottom: "6px" }}>By Department</div>
                  <ResponsiveContainer width="100%" height={150}>
                    <PieChart>
                      <Pie data={deptDonut} cx="50%" cy="50%" innerRadius={35} outerRadius={60} dataKey="value" paddingAngle={2}>
                        {deptDonut.map((d, i) => <Cell key={i} fill={d.color} />)}
                      </Pie>
                      <Tooltip formatter={(value, name) => [`${value} entries`, name]} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div style={{ display: "flex", gap: "8px", justifyContent: "center", flexWrap: "wrap" }}>
                    {deptDonut.map((d) => (
                      <div key={d.name} style={{ display: "flex", alignItems: "center", gap: "3px", fontSize: "13px", color: `var(--text-secondary, ${COLOURS.SLATE})` }}>
                        <span style={{ width: "7px", height: "7px", borderRadius: "50%", backgroundColor: d.color }} /> {d.name} ({d.value})
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Search + Group toggle */}
          <div style={{ display: "flex", gap: "8px", marginBottom: "12px", flexWrap: "wrap", alignItems: "center", position: "sticky", top: 0, zIndex: 10, backgroundColor: "var(--bg-page, #f8fafc)", paddingTop: "4px", paddingBottom: "4px" }}>
            <input type="text" placeholder="Search..." value={filter} onChange={(e) => handleFilterChange(e.target.value)}
              style={{ flex: "1 1 200px", maxWidth: "300px", padding: "7px 12px", border: `1px solid var(--border-color, ${COLOURS.HAIRLINE})`, borderRadius: "6px", fontSize: "16px", boxSizing: "border-box" }} />
            <div style={{ display: "flex", gap: "3px" }}>
              {(["time", "department", "person"] as const).map((g) => (
                <button key={g} onClick={() => setGroupBy(g)} style={{
                  backgroundColor: groupBy === g ? COLOURS.NAVY : "var(--bg-card, #ffffff)",
                  color: groupBy === g ? "white" : `var(--text-primary, ${COLOURS.NAVY})`,
                  border: `1px solid ${groupBy === g ? COLOURS.NAVY : `var(--border-color, ${COLOURS.HAIRLINE})`}`,
                  borderRadius: "5px", padding: "5px 12px", fontSize: "15px", fontWeight: 600, cursor: "pointer",
                  textTransform: "capitalize",
                }}>{g}</button>
              ))}
            </div>
          </div>

          {/* Log entries */}
          {loading ? <SkeletonRows count={5} height="40px" /> : filtered.length === 0 ? (
            <div style={{ border: `1px solid var(--border-color, ${COLOURS.HAIRLINE})`, borderRadius: "8px", padding: "14px", backgroundColor: "var(--bg-card, #ffffff)", color: `var(--text-secondary, ${COLOURS.SLATE})`, textAlign: "center" }}>No log entries found.</div>
          ) : groupBy === "time" ? (
            <div style={{ border: `1px solid var(--border-color, ${COLOURS.HAIRLINE})`, borderRadius: "8px", backgroundColor: "var(--bg-card, #ffffff)", overflow: "hidden" }}>
              {filtered.slice(0, 200).map((log) => <LogRow key={log.id} log={log} />)}
              {filtered.length > 200 && <div style={{ padding: "10px 14px", textAlign: "center", color: `var(--text-secondary, ${COLOURS.SLATE})`, fontSize: "15px" }}>Showing 200 of {filtered.length}</div>}
            </div>
          ) : groupBy === "department" ? (
            deptNames.map((dept) => {
              const entries = deptGroups.get(dept)!;
              return (
                <div key={dept} style={{ border: `1px solid var(--border-color, ${COLOURS.HAIRLINE})`, borderRadius: "8px", backgroundColor: "var(--bg-card, #ffffff)", overflow: "hidden", marginBottom: "10px" }}>
                  <div style={{ padding: "8px 14px", backgroundColor: "var(--bg-card-hover, #f8fafc)", borderBottom: `1px solid var(--border-color, ${COLOURS.HAIRLINE})`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: "16px", fontWeight: 700, color: `var(--text-primary, ${COLOURS.NAVY})` }}>{dept}</span>
                    <span style={{ fontSize: "15px", color: `var(--text-secondary, ${COLOURS.SLATE})` }}>{entries.length} entries</span>
                  </div>
                  {entries.slice(0, 20).map((log) => <LogRow key={log.id} log={log} />)}
                  {entries.length > 20 && <div style={{ padding: "8px 14px", textAlign: "center", color: `var(--text-secondary, ${COLOURS.SLATE})`, fontSize: "14px" }}>+{entries.length - 20} more</div>}
                </div>
              );
            })
          ) : (
            personNames.map((person) => {
              const entries = personGroups.get(person)!;
              return (
                <div key={person} style={{ border: `1px solid var(--border-color, ${COLOURS.HAIRLINE})`, borderRadius: "8px", backgroundColor: "var(--bg-card, #ffffff)", overflow: "hidden", marginBottom: "10px" }}>
                  <div style={{ padding: "8px 14px", backgroundColor: "var(--bg-card-hover, #f8fafc)", borderBottom: `1px solid var(--border-color, ${COLOURS.HAIRLINE})`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: "16px", fontWeight: 700, color: `var(--text-primary, ${COLOURS.NAVY})` }}>{person}</span>
                    <span style={{ fontSize: "15px", color: `var(--text-secondary, ${COLOURS.SLATE})` }}>{entries.length} actions</span>
                  </div>
                  {entries.slice(0, 20).map((log) => <LogRow key={log.id} log={log} />)}
                  {entries.length > 20 && <div style={{ padding: "8px 14px", textAlign: "center", color: `var(--text-secondary, ${COLOURS.SLATE})`, fontSize: "14px" }}>+{entries.length - 20} more</div>}
                </div>
              );
            })
          )}
        </main>
    </AuthWrapper>
  );
}
