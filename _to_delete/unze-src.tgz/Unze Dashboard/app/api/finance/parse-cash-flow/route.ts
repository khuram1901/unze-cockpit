import { NextRequest } from "next/server";
import { createServiceClient } from "../../../lib/supabase-server";
import { parseCashFlowPDF, type PdcBucket } from "../../../lib/pdf-parsers/cash-flow-parser";
import { parseBankPositionPDF } from "../../../lib/pdf-parsers/bank-position-parser";
import { reconcile, matchBankPositionToCashFlow } from "../../../lib/pdf-parsers/reconcile";
import { UTPL_COMPANY_ID, IFPL_COMPANY_ID, getCompanyById } from "../../../lib/constants";
import { requireAuth } from "../../../lib/api-auth";
import { archiveSourceDocument } from "../../../lib/document-archive";

// Replaces that (company, day)'s bucket rows on every save rather than
// appending — a re-processed day should show that day's PDC schedule
// exactly, not accumulate duplicates alongside it. Same helper as
// check-inbox/route.ts's automated ingestion path.
async function savePdcBuckets(
  supabase: ReturnType<typeof createServiceClient>,
  companyId: string,
  positionDate: string,
  buckets: PdcBucket[]
) {
  await supabase.from("pdc_maturity_buckets").delete().eq("company_id", companyId).eq("position_date", positionDate);
  if (buckets.length > 0) {
    await supabase.from("pdc_maturity_buckets").insert(
      buckets.map((b) => ({ company_id: companyId, position_date: positionDate, due_date: b.dueDate, amount: b.amount, label: b.label }))
    );
  }
}

// Writes individual payment/receipt lines to cash_sheet_uploads + cash_sheet_transactions
// and links the daily_cash_position row back to the sheet (requires migration 200).
async function saveCashSheetData(
  supabase: ReturnType<typeof createServiceClient>,
  cashFlow: Awaited<ReturnType<typeof parseCashFlowPDF>>[number],
  companyId: string,
  positionDate: string,
  uploadedBy: string,
  source: "manual_upload" | "email"
): Promise<void> {
  const csCompany = companyId === IFPL_COMPANY_ID ? "IFPL" : "UTPL";

  const { data: csSheet, error: csErr } = await supabase
    .from("cash_sheet_uploads")
    .upsert(
      {
        company: csCompany,
        sheet_date: positionDate,
        opening_balance_pkr: cashFlow.openingBalanceTotal,
        closing_balance_pkr: cashFlow.closingBalanceUnzeTrading,
        source,
        uploaded_by: uploadedBy,
      },
      { onConflict: "company,sheet_date" }
    )
    .select("id")
    .single();

  if (csErr) {
    console.error("saveCashSheetData: upsert failed:", csErr.message);
    return;
  }
  if (!csSheet?.id) return;

  // Replace all transactions for this sheet (idempotent re-upload)
  await supabase.from("cash_sheet_transactions").delete().eq("sheet_id", csSheet.id);

  const txnRows = cashFlow.transactions.map((t, sortIdx) => ({
    sheet_id: csSheet.id,
    company: csCompany,
    sheet_date: positionDate,
    txn_type: t.txn_type,
    description: t.description,
    amount_pkr: t.amount,
    sort_order: sortIdx,
  }));
  if (txnRows.length > 0) {
    await supabase.from("cash_sheet_transactions").insert(txnRows);
  }

  // Link daily_cash_position → cash_sheet_uploads (requires migration 200_cash_sheet_id_fk)
  await supabase
    .from("daily_cash_position")
    .update({ cash_sheet_id: csSheet.id })
    .eq("company_id", companyId)
    .eq("position_date", positionDate);
}

export async function POST(request: NextRequest) {
  const auth = await requireAuth(request);
  if (auth instanceof Response) return auth;

  try {
    const formData = await request.formData();
    const cashFlowFile = formData.get("cashFlow") as File | null;
    const bankPositionFile = formData.get("bankPosition") as File | null;
    const companyId = (formData.get("companyId") as string) || UTPL_COMPANY_ID;

    if (!cashFlowFile || !bankPositionFile) {
      return Response.json(
        { error: "Both cashFlow and bankPosition PDF files are required." },
        { status: 400 }
      );
    }

    const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB per file
    if (cashFlowFile.size > MAX_FILE_SIZE || bankPositionFile.size > MAX_FILE_SIZE) {
      return Response.json({ error: "Each file must be under 10 MB." }, { status: 413 });
    }

    const cashFlowBuffer = Buffer.from(await cashFlowFile.arrayBuffer());
    const bankPositionBuffer = Buffer.from(await bankPositionFile.arrayBuffer());

    const cashFlowResults = await parseCashFlowPDF(cashFlowBuffer);
    const bankPositionResults = await parseBankPositionPDF(bankPositionBuffer);

    const detectedCompanyId = cashFlowResults[0].company === "imperial" ? IFPL_COMPANY_ID : UTPL_COMPANY_ID;
    if (detectedCompanyId !== companyId) {
      const expected = getCompanyById(companyId)?.name || companyId;
      const detected = getCompanyById(detectedCompanyId)?.name || detectedCompanyId;
      return Response.json(
        {
          error: `Company mismatch: this PDF was detected as "${detected}" but you're uploading to "${expected}". Upload it from the correct company tab.`,
        },
        { status: 400 }
      );
    }

    const supabase = createServiceClient();
    const uploadedBy = (formData.get("uploadedBy") as string) || "manual";

    await Promise.all([
      archiveSourceDocument({
        supabase,
        buffer: cashFlowBuffer,
        filename: cashFlowFile.name,
        docType: "cash_flow",
        companyId,
        positionDate: cashFlowResults[0]?.date || null,
        source: "manual",
        uploadedBy,
      }),
      archiveSourceDocument({
        supabase,
        buffer: bankPositionBuffer,
        filename: bankPositionFile.name,
        docType: "bank_position",
        companyId,
        positionDate: bankPositionResults[0]?.date || null,
        source: "manual",
        uploadedBy,
      }),
    ]);

    const days: {
      date: string;
      cashFlow: Record<string, number>;
      bankPosition: { banks: Record<string, number>; totalAvailable: number; postDatedCHQs: number; postDatedCurrency: string };
      reconciliation: ReturnType<typeof reconcile>;
    }[] = [];

    for (const cashFlow of cashFlowResults) {
      const bankPosition = matchBankPositionToCashFlow(cashFlow, bankPositionResults) || (cashFlowResults.length === 1 ? bankPositionResults[0] : undefined);

      if (!bankPosition) {
        return Response.json(
          {
            error: `No matching bank position day found for cash flow date ${cashFlow.date || "(unknown)"}. Bank position PDF has: ${bankPositionResults.map((b) => b.date).join(", ") || "no readable dates"}.`,
          },
          { status: 400 }
        );
      }

      const result = reconcile(cashFlow, bankPosition);
      const positionDate = cashFlow.date || bankPosition.date;

      if (!positionDate) {
        return Response.json(
          { error: "Could not extract a date from either PDF. Please check the files." },
          { status: 400 }
        );
      }

      const { error: cashError } = await supabase.from("daily_cash_position").upsert(
        {
          company_id: companyId,
          position_date: positionDate,
          opening_balance: cashFlow.openingBalanceTotal,
          total_receipts: cashFlow.receiptsTotal,
          total_payments: cashFlow.paymentsTotal,
          closing_balance: cashFlow.closingBalanceUnzeTrading,
          post_dated_total: cashFlow.loanPostDatedCHQs,
          closing_after_post_dated: cashFlow.closingAfterLoanPostDated,
          raw_pdf_filename: cashFlowFile.name,
          uploaded_by: uploadedBy,
          reconciled: result.matches,
        },
        { onConflict: "company_id,position_date" }
      );

      if (cashError) {
        return Response.json(
          { error: `Failed to save cash flow data for ${positionDate}: ` + cashError.message },
          { status: 500 }
        );
      }

      await savePdcBuckets(supabase, companyId, positionDate, cashFlow.pdcBuckets);

      // ── Write to cash_sheet tables (new source of truth) ─────────────────
      await saveCashSheetData(supabase, cashFlow, companyId, positionDate, uploadedBy, "manual_upload");

      const { error: bankError } = await supabase.from("bank_position_snapshots").upsert(
        {
          company_id: companyId,
          position_date: positionDate,
          ...bankPosition.banks,
          total_available_balance: bankPosition.totalAvailableBalance,
          post_dated_cheques_total: bankPosition.postDatedCHQsTotal,
          post_dated_currency: bankPosition.postDatedCurrency,
          raw_pdf_filename: bankPositionFile.name,
          uploaded_by: uploadedBy,
          reconciled: result.matches,
          reconcile_notes: result.matches
            ? "Balanced"
            : `Mismatch: cash flow closing ${result.cashFlowClosing.toLocaleString()} vs bank total ${result.bankPositionTotal.toLocaleString()} (diff: ${result.diff.toLocaleString()})`,
        },
        { onConflict: "company_id,position_date" }
      );

      if (bankError) {
        return Response.json(
          { error: `Failed to save bank position data for ${positionDate}: ` + bankError.message },
          { status: 500 }
        );
      }

      days.push({
        date: positionDate,
        cashFlow: {
          openingBalance: cashFlow.openingBalanceTotal,
          receipts: cashFlow.receiptsTotal,
          payments: cashFlow.paymentsTotal,
          closingBalance: cashFlow.closingBalanceUnzeTrading,
          postDated: cashFlow.loanPostDatedCHQs,
          closingAfterPostDated: cashFlow.closingAfterLoanPostDated,
        },
        bankPosition: {
          banks: bankPosition.banks,
          totalAvailable: bankPosition.totalAvailableBalance,
          postDatedCHQs: bankPosition.postDatedCHQsTotal,
          postDatedCurrency: bankPosition.postDatedCurrency,
        },
        reconciliation: result,
      });
    }

    return Response.json({
      success: true,
      date: days[days.length - 1].date,
      cashFlow: days[days.length - 1].cashFlow,
      bankPosition: days[days.length - 1].bankPosition,
      reconciliation: days[days.length - 1].reconciliation,
      days,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return Response.json({ error: "Parse failed: " + message }, { status: 500 });
  }
}
