import { NextRequest } from "next/server";
import { createServiceClient } from "../../../lib/supabase-server";
import { requireAuth } from "../../../lib/api-auth";

function canManage(role: string, department: string | null) {
  return role === "Admin" || role === "CEO" || role === "Executive" ||
    (role === "Manager" && department === "Unze Trading Ops");
}

// Returns the total qty already issued in letters for a PO (per size)
async function getPoLetterTotals(supabase: ReturnType<typeof import("../../../lib/supabase-server").createServiceClient>, poId: string, excludeId?: string) {
  let query = supabase
    .from("authority_letters")
    .select("qty_31, qty_36, qty_45, qty_meter")
    .eq("po_id", poId);
  if (excludeId) query = query.neq("id", excludeId);
  const { data } = await query;
  return (data || []).reduce(
    (acc, r) => ({
      qty_31: acc.qty_31 + (r.qty_31 || 0),
      qty_36: acc.qty_36 + (r.qty_36 || 0),
      qty_45: acc.qty_45 + (r.qty_45 || 0),
      qty_meter: acc.qty_meter + (r.qty_meter || 0),
    }),
    { qty_31: 0, qty_36: 0, qty_45: 0, qty_meter: 0 }
  );
}

export async function GET(request: NextRequest) {
  const auth = await requireAuth(request);
  if (auth instanceof Response) return auth;

  const supabase = createServiceClient();
  const { searchParams } = new URL(request.url);
  const poId = searchParams.get("poId");
  const contractorId = searchParams.get("contractorId");
  const letterNumber = searchParams.get("letterNumber");
  const plantId = searchParams.get("plantId");
  const listAll = searchParams.get("listAll") === "true";

  // List all active letters for a plant (dispatch dropdown flow)
  if (listAll && plantId) {
    // Fetch all letters whose linked PO belongs to this plant
    const { data: letters, error: lettersErr } = await supabase
      .from("authority_letters")
      .select("*, purchase_orders!inner(id, po_number, customer_name, plant_id), contractors(id, name)")
      .eq("purchase_orders.plant_id", plantId)
      .order("created_at", { ascending: false });

    if (lettersErr) return Response.json({ error: lettersErr.message }, { status: 500 });

    // Fetch all dispatch_records for these letters in one query
    const letterIds = (letters || []).map((l) => l.id);
    const { data: allRecords } = letterIds.length > 0
      ? await supabase.from("dispatch_records").select("authority_letter_id, qty_31, qty_36, qty_45, qty_meter").in("authority_letter_id", letterIds)
      : { data: [] };

    const recordsByLetter: Record<string, { qty_31: number; qty_36: number; qty_45: number; qty_meter: number }> = {};
    for (const r of allRecords || []) {
      if (!recordsByLetter[r.authority_letter_id]) {
        recordsByLetter[r.authority_letter_id] = { qty_31: 0, qty_36: 0, qty_45: 0, qty_meter: 0 };
      }
      recordsByLetter[r.authority_letter_id].qty_31 += r.qty_31 || 0;
      recordsByLetter[r.authority_letter_id].qty_36 += r.qty_36 || 0;
      recordsByLetter[r.authority_letter_id].qty_45 += r.qty_45 || 0;
      recordsByLetter[r.authority_letter_id].qty_meter += r.qty_meter || 0;
    }

    const result = (letters || []).map((data) => {
      const po = data.purchase_orders as { id: string; po_number: string; customer_name: string } | null;
      const contractor = data.contractors as { id: string; name: string } | null;
      const dispatched = recordsByLetter[data.id] || { qty_31: 0, qty_36: 0, qty_45: 0, qty_meter: 0 };
      const opening = {
        qty_31: data.opening_dispatched_31 || 0,
        qty_36: data.opening_dispatched_36 || 0,
        qty_45: data.opening_dispatched_45 || 0,
        qty_meter: data.opening_dispatched_meter || 0,
      };
      return {
        id: data.id,
        letter_number: data.letter_number,
        expiry_date: data.expiry_date || null,
        issued_by: data.issued_by || "",
        po_id: po?.id || data.po_id,
        contractor_id: contractor?.id || data.contractor_id,
        po_number: po?.po_number || "",
        customer_name: po?.customer_name || "",
        contractor_name: contractor?.name || "",
        qty_31: data.qty_31 || 0,
        qty_36: data.qty_36 || 0,
        qty_40: 0,
        qty_45: data.qty_45 || 0,
        qty_meter: data.qty_meter || 0,
        remaining_31: Math.max(0, (data.qty_31 || 0) - opening.qty_31 - dispatched.qty_31),
        remaining_36: Math.max(0, (data.qty_36 || 0) - opening.qty_36 - dispatched.qty_36),
        remaining_40: 0,
        remaining_45: Math.max(0, (data.qty_45 || 0) - opening.qty_45 - dispatched.qty_45),
        remaining_meter: Math.max(0, (data.qty_meter || 0) - opening.qty_meter - dispatched.qty_meter),
        closed_at: data.closed_at || null,
      };
    });

    return Response.json({ letters: result });
  }

  // Lookup by letter number (plant member dispatch flow) — returns single letter with remaining balances
  if (letterNumber) {
    let q = supabase
      .from("authority_letters")
      .select("*, purchase_orders(id, po_number, customer_name, plant_id), contractors(id, name)")
      .ilike("letter_number", letterNumber.trim());
    if (plantId) {
      // Filter via the linked PO's plant_id
      q = q.eq("purchase_orders.plant_id", plantId);
    }
    const { data, error } = await q.limit(1).maybeSingle();
    if (error) return Response.json({ error: error.message }, { status: 500 });
    if (!data) return Response.json({ letter: null });

    // Compute dispatched so far (opening + all dispatch_records)
    const { data: records } = await supabase
      .from("dispatch_records")
      .select("qty_31, qty_36, qty_45, qty_meter")
      .eq("authority_letter_id", data.id);
    const dispatched = (records || []).reduce(
      (acc, r) => ({
        qty_31: acc.qty_31 + (r.qty_31 || 0),
        qty_36: acc.qty_36 + (r.qty_36 || 0),
        qty_45: acc.qty_45 + (r.qty_45 || 0),
        qty_meter: acc.qty_meter + (r.qty_meter || 0),
      }),
      {
        qty_31: data.opening_dispatched_31 || 0,
        qty_36: data.opening_dispatched_36 || 0,
        qty_45: data.opening_dispatched_45 || 0,
        qty_meter: data.opening_dispatched_meter || 0,
      }
    );

    const po = data.purchase_orders as { id: string; po_number: string; customer_name: string } | null;
    const contractor = data.contractors as { id: string; name: string } | null;

    return Response.json({
      letter: {
        id: data.id,
        letter_number: data.letter_number,
        expiry_date: data.expiry_date || null,
        po_id: po?.id || data.po_id,
        contractor_id: contractor?.id || data.contractor_id,
        po_number: po?.po_number || "",
        customer_name: po?.customer_name || "",
        contractor_name: contractor?.name || "",
        qty_31: data.qty_31 || 0,
        qty_36: data.qty_36 || 0,
        qty_45: data.qty_45 || 0,
        qty_meter: data.qty_meter || 0,
        remaining_31: Math.max(0, (data.qty_31 || 0) - dispatched.qty_31),
        remaining_36: Math.max(0, (data.qty_36 || 0) - dispatched.qty_36),
        remaining_45: Math.max(0, (data.qty_45 || 0) - dispatched.qty_45),
        remaining_meter: Math.max(0, (data.qty_meter || 0) - dispatched.qty_meter),
      },
    });
  }

  let query = supabase
    .from("authority_letters")
    .select("*, contractors(name)")
    .order("created_at", { ascending: false });

  if (poId) query = query.eq("po_id", poId);
  if (contractorId) query = query.eq("contractor_id", contractorId);

  const { data, error } = await query;
  if (error) return Response.json({ error: error.message }, { status: 500 });
  return Response.json({ letters: data || [] });
}

export async function POST(request: NextRequest) {
  const auth = await requireAuth(request);
  if (auth instanceof Response) return auth;

  const supabase = createServiceClient();
  const { data: member } = await supabase
    .from("members").select("role, department").eq("email", auth.email).single();

  if (!member || !canManage(member.role, member.department)) {
    return Response.json({ error: "Ops Manager or Admin required" }, { status: 403 });
  }

  const body = await request.json().catch(() => ({}));
  const {
    po_id, contractor_id, letter_number, issue_date, issued_by,
    expiry_date = null,
    qty_31 = 0, qty_36 = 0, qty_45 = 0, qty_meter = 0,
    opening_dispatched_31 = 0, opening_dispatched_36 = 0,
    opening_dispatched_45 = 0, opening_dispatched_meter = 0,
    notes,
  } = body;

  if (!po_id || !contractor_id || !letter_number || !issue_date || !issued_by) {
    return Response.json({ error: "po_id, contractor_id, letter_number, issue_date, issued_by are required" }, { status: 400 });
  }

  // Validate: sum of all letters for this PO must not exceed PO ordered qty
  const { data: po } = await supabase
    .from("purchase_orders")
    .select("ordered_31, ordered_36, ordered_45, ordered_meter")
    .eq("id", po_id).single();

  if (po) {
    const existing = await getPoLetterTotals(supabase, po_id);
    const overflows = [
      { size: "31ft", issued: existing.qty_31 + qty_31, ordered: po.ordered_31 },
      { size: "36ft", issued: existing.qty_36 + qty_36, ordered: po.ordered_36 },
      { size: "45ft", issued: existing.qty_45 + qty_45, ordered: po.ordered_45 },
      { size: "meter", issued: existing.qty_meter + qty_meter, ordered: po.ordered_meter },
    ].filter((s) => s.ordered > 0 && s.issued > s.ordered);

    if (overflows.length > 0) {
      const detail = overflows.map((s) => `${s.size}: authorized ${s.issued} of ${s.ordered} ordered`).join(", ");
      return Response.json({ error: `Authority letters would exceed PO ordered qty — ${detail}` }, { status: 400 });
    }
  }

  // Ensure contractor is linked to this PO
  await supabase.from("po_contractors")
    .upsert({ po_id, contractor_id }, { onConflict: "po_id,contractor_id" });

  const { data, error } = await supabase
    .from("authority_letters")
    .insert({
      po_id, contractor_id, letter_number, issue_date, issued_by,
      expiry_date: expiry_date || null,
      qty_31, qty_36, qty_45, qty_meter,
      opening_dispatched_31, opening_dispatched_36,
      opening_dispatched_45, opening_dispatched_meter,
      notes: notes || null, created_by: auth.email,
    })
    .select().single();

  if (error) return Response.json({ error: error.message }, { status: 500 });
  return Response.json({ letter: data }, { status: 201 });
}

export async function PATCH(request: NextRequest) {
  const auth = await requireAuth(request);
  if (auth instanceof Response) return auth;

  const supabase = createServiceClient();
  const { data: member } = await supabase
    .from("members").select("role, department").eq("email", auth.email).single();

  if (!member || !canManage(member.role, member.department)) {
    return Response.json({ error: "Ops Manager or Admin required" }, { status: 403 });
  }

  const body = await request.json().catch(() => ({}));
  const { id, contractor_id, letter_number, issue_date, issued_by, expiry_date, qty_31, qty_36, qty_45, qty_meter, notes, close } = body;

  if (!id) return Response.json({ error: "id is required" }, { status: 400 });

  // Close/reopen — Khuram, 18 Jul 2026: old letters with only a handful of
  // poles left uncollected (out of hundreds authorised) were warning
  // forever with no way to say "done with this one". Mirrors PO close:
  // the letter and its history stay put, it just stops nagging.
  if (close !== undefined) {
    const { data, error } = await supabase
      .from("authority_letters")
      .update(close ? { closed_at: new Date().toISOString(), closed_by: auth.email } : { closed_at: null, closed_by: null })
      .eq("id", id).select().single();
    if (error) return Response.json({ error: error.message }, { status: 500 });
    return Response.json({ letter: data });
  }

  // Validate qty cap against PO ordered totals (excluding this letter)
  const { data: existing } = await supabase
    .from("authority_letters").select("po_id").eq("id", id).single();

  if (existing?.po_id && (qty_31 !== undefined || qty_36 !== undefined || qty_45 !== undefined || qty_meter !== undefined)) {
    const { data: po } = await supabase
      .from("purchase_orders")
      .select("ordered_31, ordered_36, ordered_45, ordered_meter")
      .eq("id", existing.po_id).single();

    if (po) {
      const otherTotals = await getPoLetterTotals(supabase, existing.po_id, id);
      const overflows = [
        { size: "31ft", issued: otherTotals.qty_31 + (qty_31 ?? 0), ordered: po.ordered_31 },
        { size: "36ft", issued: otherTotals.qty_36 + (qty_36 ?? 0), ordered: po.ordered_36 },
        { size: "45ft", issued: otherTotals.qty_45 + (qty_45 ?? 0), ordered: po.ordered_45 },
        { size: "meter", issued: otherTotals.qty_meter + (qty_meter ?? 0), ordered: po.ordered_meter },
      ].filter((s) => s.ordered > 0 && s.issued > s.ordered);

      if (overflows.length > 0) {
        const detail = overflows.map((s) => `${s.size}: would authorize ${s.issued} of ${s.ordered} ordered`).join(", ");
        return Response.json({ error: `Would exceed PO ordered qty — ${detail}` }, { status: 400 });
      }
    }
  }

  // Note: authority_letters has no updated_at column (unlike purchase_orders) —
  // setting one here caused every edit to fail with "Could not find the
  // 'updated_at' column of 'authority_letters' in the schema cache".
  const updates: Record<string, unknown> = {};
  if (contractor_id !== undefined) updates.contractor_id = contractor_id;
  if (letter_number !== undefined) updates.letter_number = letter_number;
  if (issue_date !== undefined) updates.issue_date = issue_date;
  if (issued_by !== undefined) updates.issued_by = issued_by;
  if (expiry_date !== undefined) updates.expiry_date = expiry_date || null;
  if (qty_31 !== undefined) updates.qty_31 = qty_31;
  if (qty_36 !== undefined) updates.qty_36 = qty_36;
  if (qty_45 !== undefined) updates.qty_45 = qty_45;
  if (qty_meter !== undefined) updates.qty_meter = qty_meter;
  if (notes !== undefined) updates.notes = notes || null;

  const { data, error } = await supabase
    .from("authority_letters").update(updates).eq("id", id).select().single();

  if (error) return Response.json({ error: error.message }, { status: 500 });
  return Response.json({ letter: data });
}

export async function DELETE(request: NextRequest) {
  const auth = await requireAuth(request);
  if (auth instanceof Response) return auth;

  const supabase = createServiceClient();
  const { data: member } = await supabase
    .from("members").select("role, department").eq("email", auth.email).single();

  if (!member || !canManage(member.role, member.department)) {
    return Response.json({ error: "Ops Manager or Admin required" }, { status: 403 });
  }

  const body = await request.json().catch(() => ({}));
  const { id } = body;
  if (!id) return Response.json({ error: "id is required" }, { status: 400 });

  const { error } = await supabase.from("authority_letters").delete().eq("id", id);
  if (error) {
    // Postgres foreign-key "on delete restrict" violation (dispatch records
    // still point at this letter) — friendlier message than the raw error.
    if (error.code === "23503") {
      return Response.json(
        { error: "This letter has dispatch records against it — remove those first." },
        { status: 409 }
      );
    }
    return Response.json({ error: error.message }, { status: 500 });
  }
  return Response.json({ success: true });
}
