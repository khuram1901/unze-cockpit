"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "./supabase";
import { COLOURS, RADII, SHADOWS } from "./SharedUI";
import { formatDateTimeUK } from "./dateUtils";
import DateInput from "./DateInput";

// ── Types ─────────────────────────────────────────────────────────

type Participant = { member_id: string; name: string; email: string; photo_url?: string | null };

type Conversation = {
  conversation_id: string;
  name: string | null;
  is_group: boolean;
  updated_at: string;
  last_message: string | null;
  last_message_at: string | null;
  last_message_sender: string | null;
  unread_count: number;
  participants: Participant[] | null;
  is_archived: boolean;
};

type Message = {
  id: string;
  conversation_id: string;
  sender_id: string | null;
  sender_name: string;
  sender_email: string;
  content: string;
  created_at: string;
};

type MemberOption = {
  id: string;
  email: string;
  display_name: string;
  role: string;
  department: string | null;
  photo_url?: string | null;
};

// ── Helpers ───────────────────────────────────────────────────────

function convPhoto(conv: Conversation): string | null {
  if (conv.is_group) return null;
  return conv.participants?.[0]?.photo_url ?? null;
}

function convDisplayName(conv: Conversation): string {
  if (conv.is_group && conv.name) return conv.name;
  if (!conv.participants?.length) return "Chat";
  if (!conv.is_group) return conv.participants[0]?.name ?? "Chat";
  return conv.participants.map((p) => p.name.split(" ")[0]).join(", ");
}

function initials(name: string): string {
  const w = name.trim().split(/\s+/);
  return w.length >= 2 ? (w[0][0] + w[1][0]).toUpperCase() : name.slice(0, 2).toUpperCase();
}

function avatarBg(seed: string): string {
  const palette = ["#3B4CCA", "#0F7B5F", "#B4791F", "#64748B", "#0F1720"];
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) & 0xffffffff;
  return palette[Math.abs(h) % palette.length];
}

function timeLabel(iso: string | null): string {
  if (!iso) return "";
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "now";
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

async function authedFetch(url: string, opts: RequestInit = {}): Promise<Response> {
  const { data: { session } } = await supabase.auth.getSession();
  return fetch(url, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session?.access_token ?? ""}`,
      ...(opts.headers ?? {}),
    },
  });
}

// ── Tick component ────────────────────────────────────────────────

function Ticks({ read }: { read: boolean }) {
  const color = read ? "#3B4CCA" : "#94A3B8";
  return (
    <svg width="16" height="10" viewBox="0 0 16 10" fill="none" style={{ display: "inline-block", verticalAlign: "middle" }}>
      {/* First tick */}
      <path d="M1 5L4 8L9 2" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      {/* Second tick (offset right - only shown when read) */}
      {read && <path d="M5 5L8 8L13 2" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>}
      {!read && <path d="M5 5L8 8L13 2" stroke="#CBD5E1" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>}
    </svg>
  );
}

// ── Conversation list item with hover action buttons ─────────────
// Hovering reveals Archive (green) and Delete (red) buttons on the right.
// This replaces the swipe gesture which was unreliable on desktop.

function ConvListItem({
  conv, onOpen, onArchive, onDelete,
}: {
  conv: Conversation;
  onOpen: () => void;
  onArchive: () => void;
  onDelete: () => void;
}) {
  const [hovered, setHovered] = useState(false);
  const { BORDER, NAVY, SLATE, CANVAS, INK_400, BLUE } = COLOURS;
  const name = convDisplayName(conv);
  const photo = convPhoto(conv);

  return (
    <div
      style={{ position: "relative", borderBottom: `1px solid ${BORDER}` }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <button
        onClick={onOpen}
        style={{
          display: "flex", alignItems: "center", gap: 10,
          width: "100%", padding: "10px 14px",
          paddingRight: hovered ? 82 : 14,
          background: conv.unread_count > 0 ? "#EEF4FF" : "none",
          border: "none", cursor: "pointer", textAlign: "left",
          transition: "padding-right 0.1s ease, background 0.1s ease",
        }}
      >
        <div style={{ position: "relative", flexShrink: 0 }}>
          {photo ? (
            <img src={photo} alt={name}
              style={{ width: 40, height: 40, borderRadius: "50%", objectFit: "cover" }} />
          ) : (
            <div style={{
              width: 40, height: 40, borderRadius: "50%",
              background: avatarBg(conv.conversation_id),
              color: "#fff", fontSize: 14, fontWeight: 600,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              {initials(name)}
            </div>
          )}
          {conv.unread_count > 0 && (
            <span style={{
              position: "absolute", bottom: 0, right: 0,
              width: 12, height: 12, borderRadius: "50%",
              background: BLUE, border: "2px solid #fff",
            }} />
          )}
        </div>
        <div style={{ flex: 1, overflow: "hidden" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 4 }}>
            <span style={{
              fontSize: 13, fontWeight: conv.unread_count > 0 ? 700 : 500,
              color: NAVY, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
            }}>
              {name}
            </span>
            <span style={{ fontSize: 10, color: conv.unread_count > 0 ? BLUE : INK_400, flexShrink: 0, fontWeight: conv.unread_count > 0 ? 600 : 400 }}>
              {timeLabel(conv.last_message_at)}
            </span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 4, marginTop: 2 }}>
            <span style={{
              fontSize: 12, color: conv.unread_count > 0 ? NAVY : SLATE,
              fontWeight: conv.unread_count > 0 ? 500 : 400,
              overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
            }}>
              {conv.last_message
                ? (conv.is_group && conv.last_message_sender
                    ? `${conv.last_message_sender.split(" ")[0]}: ${conv.last_message}`
                    : conv.last_message)
                : "No messages yet"}
            </span>
            {conv.unread_count > 0 && (
              <span style={{
                minWidth: 18, height: 18, borderRadius: 999,
                background: BLUE, color: "#fff",
                fontSize: 10, fontWeight: 700,
                display: "flex", alignItems: "center", justifyContent: "center",
                padding: "0 4px", flexShrink: 0,
              }}>
                {conv.unread_count > 99 ? "99+" : conv.unread_count}
              </span>
            )}
          </div>
        </div>
      </button>

      {/* Action buttons revealed on hover */}
      <div style={{
        position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)",
        display: "flex", gap: 4, zIndex: 2,
        opacity: hovered ? 1 : 0,
        transition: "opacity 0.15s ease",
        pointerEvents: hovered ? "auto" : "none",
      }}>
        <button
          onClick={(e) => { e.stopPropagation(); onArchive(); }}
          title="Archive"
          style={{
            width: 30, height: 30, borderRadius: 6,
            background: COLOURS.GREEN, border: "none", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 13,
          }}
        >📁</button>
        <button
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
          title="Delete"
          style={{
            width: 30, height: 30, borderRadius: 6,
            background: COLOURS.RED, border: "none", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 13,
          }}
        >🗑</button>
      </div>
    </div>
  );
}

function ArchivedConvListItem({
  conv, onOpen, onUnarchive, onDelete,
}: {
  conv: Conversation;
  onOpen: () => void;
  onUnarchive: () => void;
  onDelete: () => void;
}) {
  const [hovered, setHovered] = useState(false);
  const { BORDER, SLATE, CANVAS, INK_400 } = COLOURS;
  const name = convDisplayName(conv);
  const photo = convPhoto(conv);

  return (
    <div
      style={{ position: "relative", borderBottom: `1px solid ${BORDER}` }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <button
        onClick={onOpen}
        style={{
          display: "flex", alignItems: "center", gap: 10,
          width: "100%", padding: "9px 14px",
          paddingRight: hovered ? 82 : 14,
          background: hovered ? CANVAS : "none",
          border: "none", cursor: "pointer", textAlign: "left",
          transition: "padding-right 0.1s ease, background 0.1s ease",
        }}
      >
        {photo ? (
          <img src={photo} alt={name}
            style={{ width: 38, height: 38, borderRadius: "50%", objectFit: "cover", flexShrink: 0, opacity: 0.6 }} />
        ) : (
          <div style={{
            width: 38, height: 38, borderRadius: "50%",
            background: avatarBg(conv.conversation_id),
            color: "#fff", fontSize: 13, fontWeight: 600,
            display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
            opacity: 0.6,
          }}>
            {initials(name)}
          </div>
        )}
        <div style={{ flex: 1, overflow: "hidden" }}>
          <div style={{ fontSize: 13, fontWeight: 500, color: SLATE, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {name}
          </div>
          <div style={{ fontSize: 11, color: INK_400, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", marginTop: 1 }}>
            {conv.last_message || "No messages"}
            {conv.last_message_at && <span style={{ marginLeft: 6 }}>· {timeLabel(conv.last_message_at)}</span>}
          </div>
        </div>
      </button>

      <div style={{
        position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)",
        display: "flex", gap: 4, zIndex: 2,
        opacity: hovered ? 1 : 0,
        transition: "opacity 0.15s ease",
        pointerEvents: hovered ? "auto" : "none",
      }}>
        <button
          onClick={(e) => { e.stopPropagation(); onUnarchive(); }}
          title="Unarchive"
          style={{
            width: 30, height: 30, borderRadius: 6,
            background: COLOURS.GREEN, border: "none", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 14,
          }}
        >↩</button>
        <button
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
          title="Delete"
          style={{
            width: 30, height: 30, borderRadius: 6,
            background: COLOURS.RED, border: "none", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 13,
          }}
        >🗑</button>
      </div>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────

type Props = {
  email: string | null;
  memberId: string | null;
  memberName: string;
  isOpen: boolean;
  onToggle: () => void;
  onClose: () => void;
  unreadCount?: number; // authoritative count from bell, works even when panel is closed
  onMessagesRead?: () => void; // called after marking messages read — lets parent refresh bell count
};

export default function ChatPanel({ email, memberId, memberName, isOpen, onToggle, onClose, unreadCount = 0, onMessagesRead }: Props) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [allMembers, setAllMembers] = useState<MemberOption[]>([]);
  const [activeConv, setActiveConv] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [othersLastReadAt, setOthersLastReadAt] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [search, setSearch] = useState("");
  const [loadingConvs, setLoadingConvs] = useState(false);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const [openingDm, setOpeningDm] = useState<string | null>(null); // email of member being opened
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [view, setView] = useState<"main" | "archived">("main");
  const [archivedConvs, setArchivedConvs] = useState<Conversation[]>([]);
  const [loadingArchived, setLoadingArchived] = useState(false);

  // @task form state
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [taskDesc, setTaskDesc] = useState("");
  const [taskDueDate, setTaskDueDate] = useState("");
  const [taskPriority, setTaskPriority] = useState("Medium");
  const [taskAssigneeEmail, setTaskAssigneeEmail] = useState("");
  const [submittingTask, setSubmittingTask] = useState(false);
  const [taskError, setTaskError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const msgChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const readChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const panelOpenedRef = useRef(false); // prevents double auto-open within a single open session

  const { NAVY, CARD, BORDER, SLATE, INK_400, INK_700, BLUE, CANVAS, INK_300, SUCCESS_SOFT, GREEN } = COLOURS;
  const totalUnread = conversations.reduce((s, c) => s + (c.unread_count ?? 0), 0);

  // ── Load conversations ──────────────────────────────────────────

  const loadConversations = useCallback(async () => {
    if (!memberId) return null;
    setLoadingConvs(true);
    const { data } = await supabase.rpc("get_my_conversations", {
      p_member_id: memberId,
      p_include_archived: false,
    });
    if (data) setConversations(data as Conversation[]);
    setLoadingConvs(false);
    return (data ?? null) as Conversation[] | null;
  }, [memberId]);

  const loadArchivedConversations = useCallback(async () => {
    if (!memberId) return;
    setLoadingArchived(true);
    const { data } = await supabase.rpc("get_my_conversations", {
      p_member_id: memberId,
      p_include_archived: true,
    });
    if (data) setArchivedConvs((data as Conversation[]).filter((c) => c.is_archived));
    setLoadingArchived(false);
  }, [memberId]);

  const conversationAction = useCallback(async (
    convId: string,
    action: "archive" | "unarchive" | "delete"
  ) => {
    // Optimistic update
    if (action === "archive") {
      setConversations((prev) => prev.filter((c) => c.conversation_id !== convId));
    } else if (action === "unarchive") {
      setArchivedConvs((prev) => {
        const conv = prev.find((c) => c.conversation_id === convId);
        if (conv) setConversations((cs) => [{ ...conv, is_archived: false }, ...cs]);
        return prev.filter((c) => c.conversation_id !== convId);
      });
    } else if (action === "delete") {
      setConversations((prev) => prev.filter((c) => c.conversation_id !== convId));
      setArchivedConvs((prev) => prev.filter((c) => c.conversation_id !== convId));
    }
    await authedFetch("/api/chat/conversations", {
      method: "PATCH",
      body: JSON.stringify({ conversation_id: convId, action }),
    });
  }, []);

  // Load members once for the people list
  const loadMembers = useCallback(async () => {
    if (allMembers.length > 0 || !email) return;
    const { data } = await supabase
      .from("members")
      .select("id, email, name, first_name, last_name, role, department, photo_url")
      .eq("is_active", true)
      .neq("email", email)
      .order("first_name");
    if (data) {
      setAllMembers(data.map((m) => ({
        id: m.id,
        email: m.email,
        display_name: `${m.first_name ?? ""} ${m.last_name ?? ""}`.trim() || m.name || m.email,
        role: m.role,
        department: m.department,
        photo_url: m.photo_url ?? null,
      })));
    }
  }, [email, allMembers.length]);

  // Load conversations and members whenever the panel opens
  useEffect(() => {
    if (isOpen) {
      loadConversations();
      loadMembers();
    }
  }, [isOpen, loadConversations, loadMembers]);

  // Auto-open the most recent unread conversation once per panel open session.
  // Runs after conversations load (reacts to state, not the fetch directly).
  useEffect(() => {
    if (!isOpen || activeConv || conversations.length === 0) return;
    if (panelOpenedRef.current) return; // already ran this session
    panelOpenedRef.current = true;
    const unread = [...conversations]
      .filter((c) => (c.unread_count ?? 0) > 0 && c.last_message !== null)
      .sort((a, b) =>
        new Date(b.last_message_at ?? 0).getTime() - new Date(a.last_message_at ?? 0).getTime()
      );
    if (unread.length > 0) setActiveConv(unread[0]);
  }, [isOpen, conversations, activeConv]);

  // Reset auto-open flag when panel closes
  useEffect(() => {
    if (!isOpen) panelOpenedRef.current = false;
  }, [isOpen]);

  // Focus search when panel opens
  useEffect(() => {
    if (isOpen && !activeConv) setTimeout(() => searchRef.current?.focus(), 120);
  }, [isOpen, activeConv]);

  // Realtime + polling when panel is open - keeps conversation list live
  useEffect(() => {
    if (!isOpen || !email) return;
    const ch = supabase
      .channel("chat-list-refresh")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" },
        () => loadConversations())
      .subscribe();
    const poll = setInterval(loadConversations, 15_000);
    return () => { supabase.removeChannel(ch); clearInterval(poll); };
  }, [isOpen, email, loadConversations]);

  // ── Load messages ───────────────────────────────────────────────

  const loadMessages = useCallback(async (convId: string, before?: string) => {
    if (!before) { setLoadingMsgs(true); setMessages([]); }
    else setLoadingMore(true);

    const url = `/api/chat/messages?conversation_id=${convId}${before ? `&before=${encodeURIComponent(before)}` : ""}`;
    const res = await authedFetch(url);
    if (!res.ok) { setLoadingMsgs(false); setLoadingMore(false); return; }

    const payload = await res.json();
    const msgs: Message[] = payload.messages ?? [];
    const readAt: string | null = payload.others_last_read_at ?? null;

    setOthersLastReadAt(readAt);
    if (before) {
      setMessages((prev) => [...msgs, ...prev]);
      setHasMore(msgs.length === 50);
    } else {
      setMessages(msgs);
      setHasMore(msgs.length === 50);
      // Notify parent to refresh bell count now that we've stamped last_read_at
      if (msgs.length > 0) onMessagesRead?.();
    }
    if (!before) setLoadingMsgs(false); else setLoadingMore(false);
  }, []);

  useEffect(() => {
    // Reset task form whenever conversation changes
    setShowTaskForm(false);
    setTaskDesc("");
    setTaskDueDate("");
    setTaskPriority("Medium");
    if (!activeConv) return;
    loadMessages(activeConv.conversation_id);
    setConversations((prev) =>
      prev.map((c) => c.conversation_id === activeConv.conversation_id ? { ...c, unread_count: 0 } : c)
    );
    setTimeout(() => inputRef.current?.focus(), 150);
  }, [activeConv, loadMessages]);

  // Scroll to bottom when messages load/change (but not on "load more")
  useEffect(() => {
    if (!loadingMore) messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loadingMore]);

  // Realtime: new messages in active conversation
  useEffect(() => {
    if (!activeConv) return;
    if (msgChannelRef.current) supabase.removeChannel(msgChannelRef.current);
    const ch = supabase
      .channel(`chat-msg-${activeConv.conversation_id}`)
      .on("postgres_changes", {
        event: "INSERT", schema: "public", table: "chat_messages",
        filter: `conversation_id=eq.${activeConv.conversation_id}`,
      }, (payload) => {
        const msg = payload.new as Message;
        setMessages((prev) => prev.some((m) => m.id === msg.id) ? prev : [...prev, msg]);
        // Stamp read (fire and forget) if message is from someone else
        if (msg.sender_email !== email) {
          authedFetch(`/api/chat/messages?conversation_id=${activeConv.conversation_id}`);
        }
      })
      .subscribe();
    msgChannelRef.current = ch;
    return () => { supabase.removeChannel(ch); };
  }, [activeConv, email]);

  // Realtime: track when other person reads (for tick updates)
  useEffect(() => {
    if (!activeConv || !memberId) return;
    if (readChannelRef.current) supabase.removeChannel(readChannelRef.current);
    const ch = supabase
      .channel(`chat-read-${activeConv.conversation_id}`)
      .on("postgres_changes", {
        event: "UPDATE", schema: "public", table: "chat_participants",
        filter: `conversation_id=eq.${activeConv.conversation_id}`,
      }, (payload) => {
        // Update othersLastReadAt if it's not us who changed
        const updated = payload.new as { member_id: string; last_read_at: string };
        if (updated.member_id !== memberId) {
          setOthersLastReadAt((prev) =>
            !prev || updated.last_read_at > prev ? updated.last_read_at : prev
          );
        }
      })
      .subscribe();
    readChannelRef.current = ch;
    return () => { supabase.removeChannel(ch); };
  }, [activeConv, memberId]);

  // ── Open a DM with a member (create if needed, then go straight in) ──

  const openDm = async (member: MemberOption) => {
    setOpeningDm(member.email);
    const res = await authedFetch("/api/chat/conversations", {
      method: "POST",
      body: JSON.stringify({ participant_emails: [member.email], is_group: false }),
    });
    const data = await res.json();
    if (!res.ok) { setOpeningDm(null); return; }

    // Build a local Conversation object immediately - don't wait for RPC
    const convObj: Conversation = {
      conversation_id: data.conversation_id,
      name: null,
      is_group: false,
      is_archived: false,
      updated_at: new Date().toISOString(),
      last_message: null,
      last_message_at: null,
      last_message_sender: null,
      unread_count: 0,
      participants: [{ member_id: member.id, name: member.display_name, email: member.email }],
    };

    setConversations((prev) => {
      const exists = prev.find((c) => c.conversation_id === data.conversation_id);
      if (exists) return prev;
      return [convObj, ...prev];
    });

    setSearch("");
    setActiveConv(convObj);
    setOpeningDm(null);
  };

  // ── Send message ────────────────────────────────────────────────

  const sendMessage = async () => {
    if (!activeConv || !newMessage.trim() || sending) return;
    const content = newMessage.trim();
    setSending(true);
    setNewMessage("");
    const res = await authedFetch("/api/chat/messages", {
      method: "POST",
      body: JSON.stringify({ conversation_id: activeConv.conversation_id, content }),
    });
    if (!res.ok) setNewMessage(content); // restore on failure
    setSending(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  // ── @task trigger ────────────────────────────────────────────────

  const openTaskForm = useCallback(() => {
    if (!activeConv) return;
    // Default assignee = first participant (other person in a 1:1)
    const firstParticipant = activeConv.participants?.[0];
    setTaskAssigneeEmail(firstParticipant?.email ?? "");
    setTaskDesc("");
    setTaskDueDate("");
    setTaskPriority("Medium");
    setTaskError(null);
    setShowTaskForm(true);
    setNewMessage(""); // clear the @task trigger text
  }, [activeConv]);

  const handleMessageChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setNewMessage(val);
    // Detect @task trigger (anywhere in text, case-insensitive)
    if (val.toLowerCase().trimEnd() === "@task") {
      openTaskForm();
    }
  };

  const submitTask = async () => {
    if (!activeConv || !taskDesc.trim() || !taskAssigneeEmail || submittingTask) return;
    setSubmittingTask(true);
    setTaskError(null);

    try {
      // Find the assignee's display name from participants
      const assignee = activeConv.participants?.find((p) => p.email === taskAssigneeEmail);
      const assigneeName = assignee?.name ?? taskAssigneeEmail;

      const res = await authedFetch("/api/tasks/create", {
        method: "POST",
        body: JSON.stringify({
          description: taskDesc.trim(),
          assignedToEmail: taskAssigneeEmail,
          assignedTo: assigneeName,
          dueDate: taskDueDate || null,
          priority: taskPriority,
          sourceType: "chat",
          sourceRecordId: activeConv.conversation_id,
          sourceLabel: `Chat with ${convDisplayName(activeConv)}`,
        }),
      });

      if (res.ok) {
        // Send a confirmation message into the chat
        const duePart = taskDueDate ? ` · Due ${taskDueDate.split("-").reverse().join("/")}` : "";
        await authedFetch("/api/chat/messages", {
          method: "POST",
          body: JSON.stringify({
            conversation_id: activeConv.conversation_id,
            content: `📋 Task assigned to ${assigneeName}: "${taskDesc.trim()}"${duePart}`,
          }),
        });
        setShowTaskForm(false);
      } else {
        const errData = await res.json().catch(() => ({}));
        setTaskError(errData.error ?? "Failed to create task. Please try again.");
      }
    } catch {
      setTaskError("Network error. Please try again.");
    } finally {
      setSubmittingTask(false);
    }
  };

  // ── Filtered + sorted data for the list ────────────────────────

  const q = search.toLowerCase().trim();
  // @ mode: typing "@" switches to new-conversation member search
  const isAtMode = search.trimStart().startsWith("@");
  const atQuery = isAtMode ? search.replace(/^@\s*/, "").toLowerCase().trim() : "";

  // Sort: unread first, then most recent
  const sortedConvs = [...conversations].sort((a, b) => {
    const aUnread = (a.unread_count ?? 0) > 0 ? 1 : 0;
    const bUnread = (b.unread_count ?? 0) > 0 ? 1 : 0;
    if (bUnread !== aUnread) return bUnread - aUnread;
    return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
  });

  // Only show conversations that have at least one message (active chats only).
  // In @ mode, hide conversations entirely so the member list has full focus.
  const filteredConvs = isAtMode
    ? []
    : sortedConvs.filter((c) => {
        if (c.last_message === null) return false; // never show empty chats
        if (q) return convDisplayName(c).toLowerCase().includes(q);
        return true;
      });

  // Members shown in @ mode (everyone) or normal search mode (matching only)
  const filteredMembers = isAtMode
    ? allMembers.filter((m) =>
        !atQuery ||
        m.display_name.toLowerCase().includes(atQuery) ||
        m.email.toLowerCase().includes(atQuery)
      )
    : q
    ? allMembers.filter((m) =>
        m.display_name.toLowerCase().includes(q) ||
        m.email.toLowerCase().includes(q)
      )
    : [];

  // Fallback: load members if not yet loaded and user types @ or a search query
  useEffect(() => {
    if ((isAtMode || q) && allMembers.length === 0) loadMembers();
  }, [isAtMode, q, allMembers.length, loadMembers]);

  if (!email) return null;

  // ── Render ──────────────────────────────────────────────────────

  return (
    <>
      {/* ── Floating button ── */}
      <button
        onClick={onToggle}
        aria-label="Chat"
        style={{
          position: "fixed", bottom: 24, right: 24,
          width: 52, height: 52, borderRadius: "50%",
          background: NAVY, border: "none", cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: SHADOWS.MODAL, zIndex: 1200,
          transition: "transform 0.15s ease",
        }}
        onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.08)")}
        onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2Z" fill="white"/>
        </svg>
        {(unreadCount > 0 || totalUnread > 0) && (
          <span style={{
            position: "absolute", top: 0, right: 0,
            minWidth: 18, height: 18, borderRadius: 999,
            background: "#B3261E", color: "#fff",
            fontSize: 10, fontWeight: 600,
            display: "flex", alignItems: "center", justifyContent: "center",
            padding: "0 4px", border: "2px solid #fff",
          }}>
            {(() => { const n = unreadCount > 0 ? unreadCount : totalUnread; return n > 99 ? "99+" : n; })()}
          </span>
        )}
      </button>

      {/* ── Slide-in panel ── */}
      <div style={{
        position: "fixed", bottom: 88, right: 24,
        width: 340, maxWidth: "calc(100vw - 32px)",
        height: "min(580px, calc(100vh - 116px))",
        borderRadius: RADII.LG,
        background: CARD,
        border: `1px solid ${BORDER}`,
        boxShadow: SHADOWS.MODAL,
        zIndex: 1199,
        display: "flex", flexDirection: "column", overflow: "hidden",
        transform: isOpen ? "translateY(0) scale(1)" : "translateY(12px) scale(0.97)",
        opacity: isOpen ? 1 : 0,
        pointerEvents: isOpen ? "auto" : "none",
        transition: "transform 0.18s ease, opacity 0.18s ease",
        transformOrigin: "bottom right",
      }}>

        {/* ── Header ── */}
        <div style={{
          display: "flex", alignItems: "center", gap: 8,
          padding: "12px 14px",
          borderBottom: `1px solid ${BORDER}`,
          flexShrink: 0,
        }}>
          {(activeConv || view === "archived") && (
            <button
              onClick={() => {
                if (activeConv) { setActiveConv(null); setMessages([]); setOthersLastReadAt(null); }
                else { setView("main"); }
              }}
              style={{ background: "none", border: "none", cursor: "pointer", color: SLATE, padding: "2px 4px 2px 0", display: "flex" }}
              aria-label="Back"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          )}
          {activeConv && (
            convPhoto(activeConv) ? (
              <img src={convPhoto(activeConv)!} alt={convDisplayName(activeConv)}
                style={{ width: 30, height: 30, borderRadius: "50%", objectFit: "cover", flexShrink: 0 }} />
            ) : (
              <div style={{
                width: 30, height: 30, borderRadius: "50%",
                background: avatarBg(activeConv.conversation_id),
                color: "#fff", fontSize: 11, fontWeight: 600,
                display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0,
              }}>
                {initials(convDisplayName(activeConv))}
              </div>
            )
          )}
          <span style={{
            fontFamily: "var(--font-display)", fontSize: 14, fontWeight: 600,
            color: NAVY, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          }}>
            {activeConv ? convDisplayName(activeConv) : view === "archived" ? "Archived chats" : "Messages"}
          </span>
          {/* New chat pencil - only on main list */}
          {!activeConv && view === "main" && (
            <button
              onClick={() => { setTimeout(() => { searchRef.current?.focus(); searchRef.current?.select(); }, 50); }}
              style={{ background: "none", border: "none", cursor: "pointer", color: SLATE, padding: 4, display: "flex" }}
              aria-label="New chat"
              title="Start a new chat"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <path d="M12 20H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                <path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          )}
          <button
            onClick={onClose}
            style={{ background: "none", border: "none", cursor: "pointer", color: SLATE, padding: 4, display: "flex" }}
            aria-label="Close"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        {/* ── List view ── */}
        {!activeConv && view === "main" && (
          <div style={{ display: "flex", flexDirection: "column", flex: 1, overflow: "hidden" }}>
            {/* Search bar */}
            <div style={{ padding: "10px 12px", borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
              <div style={{ position: "relative" }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                  style={{ position: "absolute", left: 9, top: "50%", transform: "translateY(-50%)", color: INK_400 }}>
                  <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2"/>
                  <path d="M21 21L16.65 16.65" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
                <input
                  ref={searchRef}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search chats, or type @ to find someone…"
                  style={{
                    width: "100%", padding: "7px 10px 7px 28px",
                    border: `1px solid ${BORDER}`, borderRadius: RADII.PILL,
                    fontSize: 13, color: NAVY, background: CANVAS,
                    outline: "none", boxSizing: "border-box",
                  }}
                />
              </div>
            </div>

            {/* Archived chats - pinned above the scroll, always visible */}
            <button
              onClick={() => { setView("archived"); loadArchivedConversations(); }}
              style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                width: "100%", padding: "9px 14px", flexShrink: 0,
                background: CANVAS, border: "none", borderBottom: `1px solid ${BORDER}`,
                cursor: "pointer", textAlign: "left",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = BORDER)}
              onMouseLeave={(e) => (e.currentTarget.style.background = CANVAS)}
            >
              <span style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13, color: SLATE, fontWeight: 500 }}>
                <span style={{
                  width: 34, height: 34, borderRadius: "50%",
                  background: BORDER, display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 16, flexShrink: 0,
                }}>📁</span>
                Archived chats
              </span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ color: INK_400, flexShrink: 0 }}>
                <path d="M9 18L15 12L9 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>

            <div style={{ flex: 1, overflowY: "auto" }}>
              {loadingConvs && filteredConvs.length === 0 && filteredMembers.length === 0 ? (
                <div style={{ padding: 24, textAlign: "center", color: SLATE, fontSize: 13 }}>Loading…</div>
              ) : (
                <>
                  {/* Conversations - unread first, then most recent */}
                  {filteredConvs.map((conv) => (
                    <ConvListItem
                      key={conv.conversation_id}
                      conv={conv}
                      onOpen={() => { setSearch(""); setActiveConv(conv); }}
                      onArchive={() => conversationAction(conv.conversation_id, "archive")}
                      onDelete={() => conversationAction(conv.conversation_id, "delete")}
                    />
                  ))}

                  {/* People results - shown in @ mode or when searching by name */}
                  {filteredMembers.length > 0 && (
                    <>
                      <div style={{ padding: "8px 14px 4px", fontSize: 10, fontWeight: 600, color: INK_400, letterSpacing: "0.08em", textTransform: "uppercase" }}>
                        {filteredConvs.length > 0 ? "People" : "Start conversation with…"}
                      </div>
                      {filteredMembers.map((m) => (
                        <button
                          key={m.id}
                          onClick={() => openDm(m)}
                          disabled={openingDm === m.email}
                          style={{
                            display: "flex", alignItems: "center", gap: 10,
                            width: "100%", padding: "9px 14px",
                            background: "none", border: "none",
                            borderBottom: `1px solid ${BORDER}`,
                            cursor: openingDm === m.email ? "wait" : "pointer",
                            textAlign: "left", opacity: openingDm === m.email ? 0.6 : 1,
                          }}
                          onMouseEnter={(e) => { if (!openingDm) e.currentTarget.style.background = CANVAS; }}
                          onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
                        >
                          {m.photo_url && openingDm !== m.email ? (
                            <img src={m.photo_url} alt={m.display_name}
                              style={{ width: 38, height: 38, borderRadius: "50%", objectFit: "cover", flexShrink: 0 }} />
                          ) : (
                            <div style={{
                              width: 38, height: 38, borderRadius: "50%",
                              background: avatarBg(m.id),
                              color: "#fff", fontSize: 13, fontWeight: 600,
                              display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
                            }}>
                              {openingDm === m.email ? "…" : initials(m.display_name)}
                            </div>
                          )}
                          <div>
                            <div style={{ fontSize: 13, fontWeight: 500, color: NAVY }}>{m.display_name}</div>
                            <div style={{ fontSize: 11, color: SLATE }}>{m.role}{m.department ? ` · ${m.department}` : ""}</div>
                          </div>
                        </button>
                      ))}
                    </>
                  )}

                  {/* @ mode hint when no name typed yet */}
                  {isAtMode && filteredMembers.length === 0 && !atQuery && (
                    <div style={{ padding: 32, textAlign: "center" }}>
                      <div style={{ fontSize: 28, marginBottom: 8 }}>🔍</div>
                      <div style={{ fontSize: 13, color: SLATE }}>Type a name to find someone</div>
                      <div style={{ fontSize: 12, color: INK_400, marginTop: 4 }}>e.g. @Kamran</div>
                    </div>
                  )}
                  {/* @ mode - no match */}
                  {isAtMode && atQuery && filteredMembers.length === 0 && (
                    <div style={{ padding: 32, textAlign: "center" }}>
                      <div style={{ fontSize: 13, color: SLATE }}>{`No member matching "${atQuery}"`}</div>
                    </div>
                  )}
                  {/* Normal search - no match in convs or members */}
                  {!isAtMode && q && filteredConvs.length === 0 && filteredMembers.length === 0 && !loadingConvs && (
                    <div style={{ padding: 32, textAlign: "center" }}>
                      <div style={{ fontSize: 13, color: SLATE }}>{`No results for "${q}"`}</div>
                    </div>
                  )}
                  {/* Empty state — no search query, no conversations */}
                  {!isAtMode && !q && filteredConvs.length === 0 && !loadingConvs && (
                    <div style={{ padding: 40, textAlign: "center" }}>
                      <div style={{ fontSize: 32, marginBottom: 8 }}>💬</div>
                      <div style={{ fontSize: 13, color: SLATE }}>No conversations yet</div>
                      <div style={{ fontSize: 12, color: INK_400, marginTop: 6 }}>
                        Type a name or @ to find someone to chat with
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        )}

        {/* ── Archived chats view ── */}
        {!activeConv && view === "archived" && (
          <div style={{ display: "flex", flexDirection: "column", flex: 1, overflow: "hidden" }}>
            <div style={{ flex: 1, overflowY: "auto" }}>
              {loadingArchived ? (
                <div style={{ padding: 24, textAlign: "center", color: SLATE, fontSize: 13 }}>Loading…</div>
              ) : archivedConvs.length === 0 ? (
                <div style={{ padding: 40, textAlign: "center" }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>📁</div>
                  <div style={{ fontSize: 13, color: SLATE }}>No archived chats</div>
                </div>
              ) : (
                archivedConvs.map((conv) => (
                  <ArchivedConvListItem
                    key={conv.conversation_id}
                    conv={conv}
                    onOpen={() => setActiveConv(conv)}
                    onUnarchive={() => conversationAction(conv.conversation_id, "unarchive")}
                    onDelete={() => conversationAction(conv.conversation_id, "delete")}
                  />
                ))
              )}
            </div>
          </div>
        )}

        {/* ── Conversation view ── */}
        {activeConv && (
          <div style={{ display: "flex", flexDirection: "column", flex: 1, overflow: "hidden" }}>
            {/* Messages */}
            <div style={{ flex: 1, overflowY: "auto", padding: "10px 12px 4px" }}>
              {hasMore && !loadingMore && (
                <div style={{ textAlign: "center", marginBottom: 8 }}>
                  <button
                    onClick={() => loadMessages(activeConv.conversation_id, messages[0]?.created_at)}
                    style={{
                      background: "none", border: `1px solid ${BORDER}`,
                      borderRadius: RADII.PILL, cursor: "pointer",
                      color: SLATE, fontSize: 11, padding: "4px 12px",
                    }}
                  >
                    Load earlier messages
                  </button>
                </div>
              )}
              {loadingMore && (
                <div style={{ textAlign: "center", fontSize: 11, color: SLATE, marginBottom: 8 }}>Loading…</div>
              )}

              {loadingMsgs ? (
                <div style={{ textAlign: "center", color: SLATE, fontSize: 13, padding: 24 }}>Loading…</div>
              ) : messages.length === 0 ? (
                <div style={{ textAlign: "center", padding: 32 }}>
                  <div style={{ fontSize: 28, marginBottom: 8 }}>👋</div>
                  <div style={{ fontSize: 13, color: SLATE }}>
                    Start the conversation with {convDisplayName(activeConv)}
                  </div>
                </div>
              ) : (
                messages.map((msg, i) => {
                  const isMe = msg.sender_email === email;
                  const prev = i > 0 ? messages[i - 1] : null;
                  const next = i < messages.length - 1 ? messages[i + 1] : null;

                  const showTimestamp = !prev ||
                    new Date(msg.created_at).getTime() - new Date(prev.created_at).getTime() > 15 * 60 * 1000;
                  const showSenderName = !isMe && activeConv.is_group &&
                    (!prev || prev.sender_email !== msg.sender_email || showTimestamp);
                  const isLastInGroup = !next || next.sender_email !== msg.sender_email;

                  // Is this the last message I sent? Show ticks on it.
                  const isRead = othersLastReadAt !== null &&
                    othersLastReadAt >= msg.created_at;
                  // Only show ticks on my last sent message (or all, up to you)
                  const showTicks = isMe;

                  return (
                    <div key={msg.id} style={{ marginBottom: 2 }}>
                      {showTimestamp && (
                        <div style={{ textAlign: "center", fontSize: 10, color: INK_400, margin: "8px 0 4px" }}>
                          {formatDateTimeUK(msg.created_at)}
                        </div>
                      )}
                      {showSenderName && (
                        <div style={{ fontSize: 10, color: SLATE, marginBottom: 2, marginLeft: 40 }}>
                          {msg.sender_name}
                        </div>
                      )}
                      <div style={{ display: "flex", justifyContent: isMe ? "flex-end" : "flex-start", alignItems: "flex-end", gap: 6 }}>
                        {/* Other person avatar (only on last in group) */}
                        {!isMe && (() => {
                          const senderPhoto = activeConv.participants?.find(p => p.email === msg.sender_email)?.photo_url;
                          if (!isLastInGroup) return <div style={{ width: 26, height: 26, flexShrink: 0 }} />;
                          return senderPhoto ? (
                            <img src={senderPhoto} alt={msg.sender_name}
                              style={{ width: 26, height: 26, borderRadius: "50%", objectFit: "cover", flexShrink: 0 }} />
                          ) : (
                            <div style={{
                              width: 26, height: 26, borderRadius: "50%",
                              background: avatarBg(msg.sender_email),
                              color: "#fff", fontSize: 9, fontWeight: 600,
                              display: "flex", alignItems: "center", justifyContent: "center",
                              flexShrink: 0,
                            }}>
                              {initials(msg.sender_name)}
                            </div>
                          );
                        })()}

                        <div style={{ maxWidth: "72%", display: "flex", flexDirection: "column", alignItems: isMe ? "flex-end" : "flex-start" }}>
                          <div style={{
                            padding: "8px 11px",
                            borderRadius: isMe ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                            background: isMe ? NAVY : CANVAS,
                            color: isMe ? "#fff" : NAVY,
                            fontSize: 13, lineHeight: 1.45,
                            wordBreak: "break-word",
                            border: isMe ? "none" : `1px solid ${BORDER}`,
                          }}>
                            {msg.content}
                          </div>
                          {/* Ticks on sent messages */}
                          {showTicks && (
                            <div style={{ marginTop: 2, marginRight: 2 }}>
                              <Ticks read={isRead} />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* @task inline form */}
            {showTaskForm && (
              <div style={{
                margin: "0 10px 6px",
                border: `1px solid ${BORDER}`,
                borderRadius: RADII.CARD,
                background: CANVAS,
                padding: "12px 14px",
                flexShrink: 0,
              }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: NAVY, display: "flex", alignItems: "center", gap: 6 }}>
                    <span>📋</span> Create Task
                  </span>
                  <button
                    onClick={() => setShowTaskForm(false)}
                    style={{ background: "none", border: "none", cursor: "pointer", color: SLATE, fontSize: 16, padding: 0, lineHeight: 1 }}
                    aria-label="Dismiss"
                  >✕</button>
                </div>

                {/* Assignee — for group chats show a selector */}
                {activeConv && activeConv.is_group && (activeConv.participants?.length ?? 0) > 1 && (
                  <div style={{ marginBottom: 8 }}>
                    <label style={{ fontSize: 11, fontWeight: 600, color: SLATE, display: "block", marginBottom: 3 }}>Assign to</label>
                    <select
                      value={taskAssigneeEmail}
                      onChange={(e) => setTaskAssigneeEmail(e.target.value)}
                      style={{
                        width: "100%", padding: "6px 8px",
                        border: `1px solid ${BORDER}`, borderRadius: RADII.SM,
                        fontSize: 12, color: NAVY, background: "#fff", outline: "none",
                      }}
                    >
                      <option value="">— Select person —</option>
                      {activeConv.participants?.map((p) => (
                        <option key={p.email} value={p.email}>{p.name}</option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Assignee read-only label for 1:1 */}
                {activeConv && !activeConv.is_group && (
                  <div style={{ marginBottom: 8 }}>
                    <label style={{ fontSize: 11, fontWeight: 600, color: SLATE, display: "block", marginBottom: 3 }}>Assign to</label>
                    <div style={{
                      padding: "6px 8px", fontSize: 12, color: NAVY,
                      background: "#F1F5F9", borderRadius: RADII.SM,
                      border: `1px solid ${BORDER}`,
                    }}>
                      {activeConv.participants?.[0]?.name ?? taskAssigneeEmail}
                    </div>
                  </div>
                )}

                {/* Task description */}
                <div style={{ marginBottom: 8 }}>
                  <label style={{ fontSize: 11, fontWeight: 600, color: SLATE, display: "block", marginBottom: 3 }}>Task description *</label>
                  <input
                    autoFocus
                    value={taskDesc}
                    onChange={(e) => setTaskDesc(e.target.value)}
                    placeholder="What needs to be done?"
                    maxLength={250}
                    style={{
                      width: "100%", padding: "6px 8px",
                      border: `1px solid ${BORDER}`, borderRadius: RADII.SM,
                      fontSize: 12, color: NAVY, background: "#fff",
                      outline: "none", boxSizing: "border-box",
                    }}
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); submitTask(); } }}
                  />
                </div>

                {/* Due date + priority row */}
                <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
                  <div style={{ flex: 1 }}>
                    <label style={{ fontSize: 11, fontWeight: 600, color: SLATE, display: "block", marginBottom: 3 }}>Due date</label>
                    <DateInput
                      value={taskDueDate}
                      onChange={(e) => setTaskDueDate(e.target.value)}
                      placeholder="DD/MM/YYYY"
                      style={{ fontSize: 12, padding: "6px 8px" }}
                    />
                  </div>
                  <div style={{ flex: 1 }}>
                    <label style={{ fontSize: 11, fontWeight: 600, color: SLATE, display: "block", marginBottom: 3 }}>Priority</label>
                    <select
                      value={taskPriority}
                      onChange={(e) => setTaskPriority(e.target.value)}
                      style={{
                        width: "100%", padding: "6px 8px",
                        border: `1px solid ${BORDER}`, borderRadius: RADII.SM,
                        fontSize: 12, color: NAVY, background: "#fff", outline: "none",
                      }}
                    >
                      <option>Low</option>
                      <option>Medium</option>
                      <option>High</option>
                    </select>
                  </div>
                </div>

                {/* Error */}
                {taskError && (
                  <div style={{
                    marginBottom: 8, padding: "6px 10px",
                    background: "#FEF2F2", border: "1px solid #FECACA",
                    borderRadius: RADII.SM, fontSize: 11, color: COLOURS.RED,
                  }}>
                    {taskError}
                  </div>
                )}

                {/* Actions */}
                <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                  <button
                    onClick={() => setShowTaskForm(false)}
                    style={{
                      padding: "6px 14px", borderRadius: RADII.PILL,
                      border: `1px solid ${BORDER}`, background: "none",
                      fontSize: 12, color: SLATE, cursor: "pointer",
                    }}
                  >Cancel</button>
                  <button
                    onClick={submitTask}
                    disabled={!taskDesc.trim() || !taskAssigneeEmail || submittingTask}
                    style={{
                      padding: "6px 14px", borderRadius: RADII.PILL,
                      border: "none", background: NAVY,
                      fontSize: 12, color: "#fff", fontWeight: 600,
                      cursor: !taskDesc.trim() || !taskAssigneeEmail || submittingTask ? "not-allowed" : "pointer",
                      opacity: !taskDesc.trim() || !taskAssigneeEmail || submittingTask ? 0.5 : 1,
                    }}
                  >{submittingTask ? "Creating…" : "Create Task"}</button>
                </div>
              </div>
            )}

            {/* @task hint shown in input placeholder when not showing form */}
            {/* Input */}
            <div style={{
              padding: "8px 10px",
              borderTop: `1px solid ${BORDER}`,
              display: "flex", gap: 8, alignItems: "flex-end", flexShrink: 0,
            }}>
              <textarea
                ref={inputRef}
                value={newMessage}
                onChange={handleMessageChange}
                onKeyDown={handleKeyDown}
                placeholder="Message… or type @task to assign a task"
                rows={1}
                maxLength={2000}
                style={{
                  flex: 1, padding: "8px 10px",
                  border: `1px solid ${BORDER}`, borderRadius: 20,
                  fontSize: 13, color: NAVY, background: CANVAS,
                  outline: "none", resize: "none",
                  fontFamily: "var(--font-sans)", lineHeight: 1.4,
                  maxHeight: 80, overflowY: "auto",
                }}
                onInput={(e) => {
                  const el = e.currentTarget;
                  el.style.height = "auto";
                  el.style.height = `${Math.min(el.scrollHeight, 80)}px`;
                }}
              />
              <button
                onClick={sendMessage}
                disabled={!newMessage.trim() || sending}
                style={{
                  width: 36, height: 36, borderRadius: "50%",
                  background: newMessage.trim() && !sending ? NAVY : INK_300,
                  border: "none",
                  cursor: newMessage.trim() && !sending ? "pointer" : "not-allowed",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0, transition: "background 0.15s",
                }}
                aria-label="Send"
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                  <path d="M22 2L11 13" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
